# auditoria_hospitalar

Estrutura simples (Flask) para rodar no seu servidor.

## Rodar
```powershell
python -m venv .venv
.\.venv\Scripts\Activate
pip install -r requirements.txt
python app.py
```
Acesse http://localhost:5000

## Importar planilha
Página inicial tem um formulário de upload. O app prioriza a aba 'OUTUBRO 2025 HU' se existir.
