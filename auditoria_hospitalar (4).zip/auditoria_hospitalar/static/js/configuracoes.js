// Stubs mínimos só pra tela não quebrar. Depois trocamos por fetch() nas rotas /api.
function abrirModalConvenio(){ try{ new bootstrap.Modal(document.getElementById('modalConvenio')).show(); }catch(e){} }
function abrirModalSetor(){ try{ new bootstrap.Modal(document.getElementById('modalSetor')).show(); }catch(e){} }
function abrirModalResponsavel(){ try{ new bootstrap.Modal(document.getElementById('modalResponsavel')).show(); }catch(e){} }
function abrirModalCausa(){ try{ new bootstrap.Modal(document.getElementById('modalCausa')).show(); }catch(e){} }
function abrirModalTipoErro(){ try{ new bootstrap.Modal(document.getElementById('modalTipoErro')).show(); }catch(e){} }

function salvarConvenio(){ /* implementar depois */ }
function salvarSetor(){ /* implementar depois */ }
function salvarResponsavel(){ /* implementar depois */ }
function salvarCausa(){ /* implementar depois */ }
function salvarTipoErro(){ /* implementar depois */ }
function filtrarCausas(){ /* implementar depois */ }
